#define _CRT_SECURE_NO_WARNINGS


// required to enable use of scanf() and printf()

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

extern int errno;

#define bool int

#define MENU_OPTION_VIEW_CARS  'a'
#define MENU_OPTION_BUY_CARS   'b'
#define MENU_OPTION_VIEW_SALES  'c'
#define MENU_OPTION_EXIT       'x'

#define DISCOUNT_PERCENTAGE 0.20f
#define MAX_CARS 80
#define TRUE 1
#define FALSE 0
// create a new data type called "bool" that can accept unsigned char type values
// min value: 0     max value: 255
#define bool unsigned char

/* Variables that can be used inside any Function created below */
// don't need negative values, so unsigned short is most appropriate
unsigned short carsAvailable = 80, carsNeeded = 0, customerAge;
long totalPrice;
// this will track how many car sales took place
// this will also be used as the index/position of each sale within the following arrays:
//		carsAmountPerSale, carsPerSale, discountGivenPerSale, customerName
unsigned short numberOfSales = 0;
// this array will hold the number of cars sold each sale
unsigned short carsAmountPerSale[MAX_CARS];
// this array will hold the number of cars sold each sale
unsigned short carsModelPerSale[MAX_CARS];
// this array will hold discount information about each sale
unsigned short discountGivenPerSale[MAX_CARS];

// this array will hold information about each model of car;
// the data is synchronised with the data within the carModel array
long carPrice[8] = { 8000, 9000, 7000, 6000, 4000, 5000, 3000, 2000 };
// this array will hold the name of each model of car, for the user's benefit
// the data is synchronised with the data within the carPrices array
char carModel[8][11] = { "toyota", "mercedez", "honda", "togg", "audi", "daimler","jeep", "land rover", };
short  carModelNeeded;
// this array will hold the name of the customer for each sale, a maximum of 200 characters per name
char customerName[MAX_CARS][250];
// this is the variable for the buyers that are an employee
employeeResponse;

bool giveDiscount = FALSE;

// this is the number of each car model
// it will update the remaining amount each time the user bought a model
int modelAmount[] = { 15, 5, 8, 9, 13, 14, 6, 10 };
short totalCarsSold = 0;



void clearScreen() {
	// this tells the Command Prompt (i.e. the System's output mechanisn)
	// to do something to clear the screen/console
	// this is purely for the user's benefit, to keep the screen clear of clutter
	system("cls");
}

void pauseProgram(char userChoice) {
	// give the user a chance to read the previous output, allow them to continue when ready
		// customise the output depending on the user's choice
	if (userChoice == MENU_OPTION_EXIT) {
		printf("\n\npress enter to exit...");
	}
	else {
		printf("press enter to return to main menu...");
	}

	// two of these getchar() are needed to skip the newline character
   //		that's likely floating around the console window
   // however, if the userChoice value is an underscore character,
   //		then this is only used when pausing after a file error occurred
   //		so only one getchar() is needed
	if (userChoice != '_') {
		getchar();
	}
	getchar();
}

void menu() {
	// start by greeting the user
	printf("Welcome to Alifa Automobiles");
	printf("\n\na. view cars");
	printf("\nb. buy cars");
	printf("\nc.view sales");
	printf("\nx. exit");
	printf("\nPlease choose from the option above...\n");
}

char getCharFromConsole(char message[201]) {
	char userInput;

	printf(message);
	scanf(" %c", &userInput);
	return userInput;
}

void swapUnsignedShort(unsigned short* a, unsigned short* b) {
	unsigned short temp;
	// copy the value found at the pointer a's address into the newly created temp variable
	temp = *a;
	// copy the value found at the pointer a's address into the address represented by the pointer b
	*a = *b;
	// copy the value of the temp variable to the pointer b's address
	*b = temp;
}

void swapBool(bool* a, bool* b) {
	bool temp;
	// copy the value found at the pointer a's address into the newly created temp variable
	temp = *a;
	// copy the value found at the pointer a's address into the address represented by the pointer b
	*a = *b;
	// copy the value of the temp variable to the pointer b's address
	*b = temp;
}


unsigned short getunsignedshortfromconsole(unsigned short message[201]) {
	// prompt user using the value of the given message
	printf(message);
	scanf("%hd", &carModelNeeded);
	// finally, return/export the value so it can be used by whatever statement called this Function
	return carModelNeeded;
}


void menu_option_view_cars() {

	int numberOfCars = sizeof(carPrice) / sizeof(long);

	for (int i = 0; i < numberOfCars; i++) {
		for (int j = i + 1; j < numberOfCars; j++) {

			if (modelAmount[i] < modelAmount[j]) {

				swapUnsignedShort(&modelAmount[i], &modelAmount[j]);

				char chTemp[255];
				strcpy(chTemp, carModel[i]);

				strcpy(carModel[i], carModel[j]);

				strcpy(carModel[j], chTemp);
			}
		}
		printf("\n%d-%s-%d\n", i, carModel[i], modelAmount[i]);

	}
	printf("\nPress ENTER to return to main menu... ");

	getchar();

	getchar();

}


void menu_option_buy_cars() {
	char userChoice;
	if (carsAvailable >= 1) {
		printf("There are %hd cars Available.", carsAvailable);
	}
	else {
		printf("Out of stock");
		return;
	}

	// this records the customers name into the "customerNames" array at position "numberOfSales"
	printf("\nWhat is your Name?... ");

	scanf(" %[^\n]s", customerName[numberOfSales]);

	printf("\nHow many cars would you like to buy?\nAmount... ");

	scanf("%hd", &carsNeeded);
	// we ask for the users age
	printf("\nHow old are you?... ");
	scanf("%hd", &customerAge);

	// check if we have enough tickets
   // no "else" needed here
	if (carsNeeded > carsAvailable) {
		printf("sorry, there are only few cars remaining");

		return;



		getchar();
		getchar();
	}
	carsAmountPerSale[numberOfSales] = carsNeeded;
	//carsAmountPerSale[numberOfSales] = carsNeeded;
	 // calculate the number of car Models by asking the carPrices
	// array about how many bytes it holds in memory and dividing that
	// result by the number of bytes a long data type holds in memory
	// the division result will be the number of car models (3 in this case)
	int numberOfCars = sizeof(carPrice) / sizeof(long);

	for (int i = 0; i < numberOfCars; i++) {
		printf("\n%d-%s", i, carModel[i]);

	}

	carModelNeeded = getunsignedshortfromconsole("\nchoose a car model...");




	switch (carModelNeeded) {


	case 0:

		if (carsNeeded > modelAmount[0]) {
			printf("there are fewer toyota remaining than you require ");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;

		}
		//this will update the number of cars remaining
		modelAmount[0] = modelAmount[0] - carsNeeded;
		break;

	case 1:

		if (carsNeeded > modelAmount[1]) {
			printf("There are fewer mercedez remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}
		//this will update the number of cars remaining
		modelAmount[1] = modelAmount[1] - carsNeeded;
		break;

	case 2:

		if (carsNeeded > modelAmount[2]) {
			printf("There are fewer honda remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}

		//this will update the number of cars remaining
		modelAmount[2] = modelAmount[2] - carsNeeded;
		break;

	case 3:

		if (carsNeeded > modelAmount[3]) {
			printf("There are fewer togg remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}
		//this will update the number of cars remaining
		modelAmount[3] = modelAmount[3] - carsNeeded;
		break;

	case 4:

		if (carsNeeded > modelAmount[4]) {
			printf("There are fewer audi remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}
		//this will update the number of cars remaining
		modelAmount[4] = modelAmount[4] - carsNeeded;
		break;
	case 5:

		if (carsNeeded > modelAmount[5]) {
			printf("There are fewer daimler remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}
		//this will update the number of cars remaining
		modelAmount[5] = modelAmount[5] - carsNeeded;
		break;

	case 6:

		if (carsNeeded > modelAmount[6]) {
			printf("There are fewer jeep remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}
		//this will update the number of cars remaining
		modelAmount[6] = modelAmount[6] - carsNeeded;
		break;

	case 7:

		if (carsNeeded > modelAmount[7]) {
			printf("There are fewer land rover remaining than you require");
			printf("\n\npress enter to go back to menu... ");
			getchar();
			getchar();
			return;
		}
		//this will update the number of cars remaining
		modelAmount[7] = modelAmount[7] - carsNeeded;

		break;

	default:
		printf("invalid input");
		getchar();
		getchar();
		return;

	}



	carsModelPerSale[numberOfSales] = carModelNeeded;

	totalPrice = carsNeeded * carPrice[carModelNeeded];

	carsAvailable -= carsNeeded;

	printf("\nAre you an EU citizen? Answer 'y' or 'n' ");
	scanf(" %c", &userChoice);

	switch (userChoice) {
	case 'y':

		totalPrice *= DISCOUNT_PERCENTAGE;

		printf("You get a Discount");

		giveDiscount = TRUE;

		break;

	case 'n':
		// asking if the buyer is a company employee
		printf("Are you an Employee of Alifa Automobiles...? Answer 'y' or 'n' ");

		scanf(" %c", &employeeResponse);

		if (employeeResponse == 'y') {
			printf("you have a discount");
			totalPrice *= DISCOUNT_PERCENTAGE;
			giveDiscount = TRUE;
		}

		else if (employeeResponse == 'n') {
			printf("you dont get a discount");
			totalPrice *= DISCOUNT_PERCENTAGE;
			giveDiscount = FALSE;


		}
		break;


	default:
		printf("invalid input");
		getchar();
		getchar();
		return;

		break;

	}

	discountGivenPerSale[numberOfSales] = giveDiscount;
	// present the outcome
	printf("\n\nYou have successfully bought %hd cars.", carsNeeded);

	printf("\nYour total price is %ld EUR", totalPrice);

	printf("\nThere are %hd cars Remaining.", carsAvailable);

	printf("\nThank You.");

	getchar();
	getchar();
	// finally, add 1 to the numberOfSales counter
	numberOfSales++;
}





void menu_option_view_sales() {




	printf("sales stats:");

	/* Variables - these are only used inside menu_viewSales() Function and nowhere else */
	// these two will contain the sum the total sales price and total number of cars sold for all sales
	long totalSalesValue = 0;
	int totalCarsSold = 0;

	printf("All sales data\n\n");

	// set up a for loop that will execute the block of code as many times as
   // indicated by the numberOfSales variable's value
	for (int i = 0; i < numberOfSales; i++) {
		int modelOfCar = carsModelPerSale[i];

		long price = carsAmountPerSale[i] * carPrice[modelOfCar];





		char discountGivenText[4];

		if (discountGivenPerSale[i] == TRUE) {
			strcpy(discountGivenText, "YES");

			price *= DISCOUNT_PERCENTAGE;
		}
		else {
			strcpy(discountGivenText, "NO");
		}
		-
			printf("Sale Index: %d | Sale Amount: %ld | Car Model: %s |"
				"Car Price: %ld | Number Of Cars: %hd | "
				"Discount Given: %s | Customer Name: %s\n",
				i, price, carModel[modelOfCar],
				carPrice[modelOfCar], carsAmountPerSale[i],
				discountGivenText, customerName[i]);

		totalSalesValue += price;
		totalCarsSold += carsAmountPerSale[i];




	}

	printf("\n%d cars have been sold with a total value of %ld EUR. There are %hd cars unsold.\n",
		totalCarsSold, totalSalesValue, carsAvailable);
	printf("\n\nPress enter to return back to menu... ");

	getchar();
	getchar();



}



void main() {

	FILE* fileName;

	fileName = fopen("viewsales.csv", "r");



	if (fileName != NULL) {
		int lineCounter = 0;



		// this is an infinite loop, we'll manually stop it once we reach the end of the file
		while (1) {



			unsigned short carsAmountPerSaleValue = 0, carsModelPerSaleValue = 0, discountGivenPerSaleValue = 0;
			char customerNameValue[201] = "";



			int scanResult = fscanf(
				fileName, // the file stream
				"%hd,%hd,%hd,%[^\n]s", // the format of the line
				&carsAmountPerSaleValue, // the variables, one for each placeholder in the format above
				&carsModelPerSaleValue,
				&discountGivenPerSaleValue,
				&customerNameValue
			);



			// if we reached the end of the file
			if (scanResult == EOF) {
				// then, stop the loop
				break;
			}



			// add the bits of data that were read above into the correct arrays
			carsAmountPerSale[lineCounter] = carsAmountPerSaleValue;
			carsModelPerSale[lineCounter] = carsModelPerSaleValue;
			// also cast (convert) the discountGivenPerSaleValue from unsigned short to a bool type
			// before putting it in the discountGivenPerSale array

			discountGivenPerSale[lineCounter] = (bool)discountGivenPerSaleValue;
			// need to use strcpy here because we're working with strings
			strcpy(customerName[lineCounter], customerNameValue);



			// increment the lineCounter, ready for next line that might be read
			lineCounter++;
		}



		// make sure the numberOfSales variable is also aware of how many sales are available after the above operation
		numberOfSales = lineCounter;
	}



	fclose(fileName);




	/* Variables - these are only used inside main() Function and nowhere else */
	// this will hold the user's choice when presented with the menu
	char userChoice;

	// loop/repeat the code between the immediately following curly brackets
   // for as long as the CONDITION found between the while()'s brackets
   // (see towards the end of void main() { ... }) evaluates to TRUE; in our case,
   // we'll keep repeating for as long as the user does not choose to Exit
   // i.e. pushes 'x' when asked to choose their next action

	do {


		clearScreen();
		menu();

		userChoice = getCharFromConsole("please choose an option:");
		// for the user's benefit...
		clearScreen();
		// next, we check the user's choice and make a decision based on that
		switch (userChoice) {
		case MENU_OPTION_VIEW_CARS:
			menu_option_view_cars();
			break;

		case MENU_OPTION_BUY_CARS:
			menu_option_buy_cars();
			break;

		case MENU_OPTION_VIEW_SALES:
			menu_option_view_sales();
			break;
		case MENU_OPTION_EXIT:

			fileName = fopen("viewsales.csv", "w");
			if (fileName != NULL) {
				for (int i = 0; i < numberOfSales; i++) {



					// this string will be built up bit by bit before being written to the opened file
					char line[201];
					// this string will contain the converted int value
					char data[50];



					// convert the unsigned short value into a string, put it in the data string variable;
					// the "10" refers to base 10, which is what regular numeric values are written in
					// e.g. saying you're 22 years old means that 22, in this case, is written in base 10
					// because that's how we people use numbers by default
					// also cast the unsigned short value into an int type before converting
					_itoa((int)carsAmountPerSale[i], data, 10);
					// add the amount of tickets to the line; first time we use strcpy,
					// then strcat to add more to the string
					strcpy(line, data);
					// add a comma to separate this value from the next on this line
					strcat(line, ",");



					// convert the value into a string
					_itoa((int)carsModelPerSale[i], data, 10);
					// add the model of car to the line
					strcat(line, data);
					// add a comma to separate this value from the next on this line
					strcat(line, ",");



					// convert the value into a string
					_itoa((int)discountGivenPerSale[i], data, 10);
					// add the discount given to the line
					strcat(line, data);
					// add a comma to separate this value from the next on this line
					strcat(line, ",");



					// add the customer name to the line
					strcat(line, customerName[i]);



					// write line to file
					fprintf(fileName, line);



					// only add a newline character if we're not yet writing the very last
					// line in the file
					if (i < numberOfSales - 1) {
						fprintf(fileName, "\n");
					}
				}



			}
			fclose(fileName);
			break;
		}


	} while (userChoice != MENU_OPTION_EXIT);

	// keep the screen clear again
	clearScreen();
	// thanking the customer
	printf("thank you for using this Car Sales Program. Bye!");

	printf("\n\nHave a nice day!\n\n");


	return 0;

}

